$(document).ready(function(){

$(".purpleleaf").mouseenter(function(){
    $(".yellowleaf, .pinkleaf").fadeOut("slow");
})
.mouseleave(function(){
    $(".yellowleaf, .pinkleaf").fadeIn("slow");
});

$(".purpleleaf").click(function(){
    $(".greenleaf").fadeIn(4000);
});

$(".reset").click(function(){
    $(".greenleaf").hide();
});


// flowers jquery

$(".tulip").click(function(){
    $(".tuliptext").toggle();
    $(this).toggleClass("front");
    $(".daisy,.rose,.lily").toggle();
});

$(".rose").click(function(){
    $(".rosetext").toggle();
    $(this).toggleClass("front");
    $(".tulip,.lily,.daisy").toggle();
});

$(".lily").click(function(){
    $(".lilytext").toggle();
    $(this).toggleClass("front");
    $(".tulip,.rose,.daisy").toggle();
});

$(".daisy").click(function(){
    $(".daisytext").toggle();
    $(this).toggleClass("front");
    $(".tulip,.rose,.lily").toggle();
});


});
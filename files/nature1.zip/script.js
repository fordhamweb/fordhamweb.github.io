$(document).ready(function(){

$(".purpleleaf").mouseenter(function(){
    $(".yellowleaf, .pinkleaf").fadeOut("slow");
})
.mouseleave(function(){
    $(".yellowleaf, .pinkleaf").fadeIn("slow");
});

$(".purpleleaf").click(function(){
    $(".greenleaf").fadeIn(4000);
});

$(".reset").click(function(){
    $(".greenleaf").hide();
});




});
$(document).ready(function(){

// leaves

$(".yellow-leaf, .pink-leaf, .green-leaf").click(function(){
    $(this).hide();
});

$(".reset").click(function(){
    $(".yellow-leaf, .pink-leaf, .green-leaf").show();
});

$(".purple-leaf").click(function(){
    $(".purple-leaf2").fadeIn(6000)
});







});

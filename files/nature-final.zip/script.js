$(document).ready(function(){



$(".purpleleaf").mouseenter(function(){
    $(".yellowleaf, .pinkleaf").fadeOut("slow");
})
.mouseleave(function(){
    $(".yellowleaf, .pinkleaf").fadeIn("slow");
});

$(".purpleleaf").click(function(){
    $(".greenleaf").fadeIn(4000);
});

$(".reset").click(function(){
    $(".greenleaf").hide();
});


// flowers jquery

$(".tulip").click(function(){
    $(".tuliptext").toggle();
    $(this).toggleClass("front");
    $(".daisy,.rose,.lily").toggle();
});

$(".rose").click(function(){
    $(".rosetext").toggle();
    $(this).toggleClass("front");
    $(".tulip,.lily,.daisy").toggle();
});

$(".lily").click(function(){
    $(".lilytext").toggle();
    $(this).toggleClass("front");
    $(".tulip,.rose,.daisy").toggle();
});

$(".daisy").click(function(){
    $(".daisytext").toggle();
    $(this).toggleClass("front");
    $(".tulip,.rose,.lily").toggle();
});



// LAST SECTION of SLIDESHOWS

// SHOW1
var slides = $('.flowerpic');
var slideIndex = 0;

$(slides[slideIndex]).fadeIn();

setInterval(function() {
    $(slides[slideIndex]).fadeOut();
    slideIndex = (slideIndex + 1) % slides.length;

    $(slides[slideIndex]).fadeIn();
}, 2000);


// SHOW2
var slidesTwo = $('.name');
var slideIndexTwo = 0;

$(slidesTwo[slideIndexTwo]).fadeIn();

setInterval(function() {
    $(slidesTwo[slideIndexTwo]).fadeOut();
    slideIndexTwo = (slideIndexTwo + 1) % slidesTwo.length;

    $(slidesTwo[slideIndexTwo]).fadeIn();
}, 2000);



});
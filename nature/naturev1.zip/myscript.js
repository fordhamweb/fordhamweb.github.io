$(document).ready(function(){

$(".purpleleaf").hover(function(){
    $(".yellowleaf").fadeIn(3000);
    $("h1").fadeIn(1000);
    $(".greenleaf").fadeIn(5000);
});





});